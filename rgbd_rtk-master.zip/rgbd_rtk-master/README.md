============================
Natalnet/LPR RGB-D Reconstruction Toolkit
============================

------------
Introduction
------------

A set of utility code built by the Natalnet/LPR group for 3D reconstruction
applications using RGB-D (e.g. Microsoft Kinect) cameras.

------------
Requirements
------------

- OpenCV: www.opencv.org
- PCL: www.pointclouds.org

<!--
--------
Building
--------
--

-------
License
-------

-------
Authors
------->